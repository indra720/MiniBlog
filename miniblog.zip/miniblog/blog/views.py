from django.shortcuts import render,HttpResponseRedirect,redirect
from .forms import SignUpForm,LoginForm,PostForm,CommentForm
from django.contrib import messages
from django.contrib.auth import authenticate,login as auth_login,logout
from .models import Post,Comment
from django.contrib.auth.models import Group
# Create your views here.

# def base(request):
#     return render(request,'blog/base.html')

from django.db.models import Q


def home(request):
    query = request.GET.get('q')
    sort = request.GET.get('sort')

    posts = Post.objects.all()

    # Search
    if query:
        posts = posts.filter(
            Q(title__icontains=query) |
            Q(desc__icontains=query) |
            Q(category__icontains=query)
        )

    # Sort
    if sort == 'latest':
        posts = posts.order_by('-created_at')
    elif sort == 'az':
        posts = posts.order_by('title')
    elif sort == 'za':
        posts = posts.order_by('-title')

    return render(request, 'blog/home.html', {'posts': posts})


def about(request):
    return render(request,'blog/about.html')

def contact(request):
    return render(request,'blog/contact.html')

def dashboard(request):
    if request.user.is_authenticated:
        posts = Post.objects.all()
        user = request.user
        fullname = user.get_full_name()
        gps = user.groups.all()
        return render(request, 'blog/dashboard.html',{'posts':posts,'fullname':fullname,'groups':gps})
    else:
        return HttpResponseRedirect('login') 


def user_logout(request):
    logout(request)
    return HttpResponseRedirect('/')

def signup(request):
    if request.method == "POST":
        form = SignUpForm(request.POST)
        if form.is_valid():
            messages.success(request, 'Congratulations! You have become an Author.')
            user = form.save()

            # Fix added here: check if group exists, otherwise create
            group, created = Group.objects.get_or_create(name='Author')
            user.groups.add(group)

            return redirect('blog:login')  # Optional: redirect to login page after signup
    else:
        form = SignUpForm()
    return render(request, 'blog/signup.html', {'form': form})



def login(request):
    # if authenitacated that means login h laready
    if not request.user.is_authenticated:
        if request.method == 'POST':
            form = LoginForm(request=request, data=request.POST)
            if form.is_valid():
                uname = form.cleaned_data['username']
                upass = form.cleaned_data['password']
                user = authenticate(username=uname, password=upass)
                if user is not None:
                    auth_login(request, user)
                    messages.success(request, 'Logged in Successfully')
                    return redirect('blog:dashboard')  # Using the URL name with namespace
        else:
            form = LoginForm()
        return render(request, 'blog/login.html', {'form': form})
    else:
        return redirect('blog:dashboard')

# add new post

from django.shortcuts import render, redirect
from django.shortcuts import redirect

from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from .forms import PostForm
from .models import Post

def addpost(request):
    if request.user.is_authenticated:
        if request.method == 'POST':
            form = PostForm(request.POST)
            if form.is_valid():
                title = form.cleaned_data['title']
                desc = form.cleaned_data['desc']
                pst = Post(title=title, desc=desc)
                pst.save()
                return redirect('blog:dashboard')  # ✅ redirect after save
        else:
            form = PostForm()
        return render(request, 'blog/addpost.html', {'form': form})
    else:
        return HttpResponseRedirect('login')

def updatepost(request, id):
    if request.user.is_authenticated:
        if request.method == 'POST':
            pi = Post.objects.get(pk=id)
            form = PostForm(request.POST, instance=pi)
            if form.is_valid():
                form.save()
                return redirect('blog:dashboard')  # ✅ redirect after update
        else:
            pi = Post.objects.get(pk=id)
            form = PostForm(instance=pi)
        return render(request, 'blog/updatepost.html', {'form': form})
    else:
        return HttpResponseRedirect('login')




from django.urls import reverse

def deletepost(request, id):
    if request.user.is_authenticated:
        if request.method == 'POST':
            pi = Post.objects.filter(pk=id).first()  
            if pi:  
                pi.delete()
            return redirect(reverse('blog:dashboard'))  
    else:
        return redirect(reverse('blog:login'))
    

def post_detail(request, id):
    post = Post.objects.get(pk=id)
    comments = post.comments.all()
    if request.method == 'POST':
        comment_form = CommentForm(request.POST)
        if comment_form.is_valid():
            new_comment = comment_form.save(commit=False)
            new_comment.post = post
            new_comment.save()
    else:
        comment_form = CommentForm()
    return render(request, 'blog/post_detail.html', {'post': post, 'comments': comments, 'comment_form': comment_form})

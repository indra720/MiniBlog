from django.db import models

import datetime

# Create your models here.

# class Post(models.Model):
#     title = models.CharField(max_length=150)
#     desc = models.TextField()


class Post(models.Model):
    CATEGORY_CHOICES = [
        ('hospital', 'Hospital'),
        ('college', 'College'),   
        ('tech', 'Technology'),
        ('other', 'Other'),
    ]
    title = models.CharField(max_length=150)
    desc = models.TextField()
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='other')
    created_at = models.DateTimeField(default=datetime.datetime.now)
    image = models.ImageField(upload_to='post_images/', blank=True, null=True)

    def __str__(self):
        return self.title
    
class Comment(models.Model):
    post = models.ForeignKey(Post, related_name='comments', on_delete=models.CASCADE)
    name = models.CharField(max_length=50)
    body = models.TextField()
    created_on = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'Comment by {self.name} on {self.post.title}'
    